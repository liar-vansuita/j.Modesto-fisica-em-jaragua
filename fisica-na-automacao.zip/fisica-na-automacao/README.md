# A Física na Automação — Em Jaraguá do Sul

Site interativo (experimento virtual) sobre a Física aplicada à automação residencial e industrial, com foco em equipamentos comuns em Jaraguá do Sul.

## O que tem no site

- Página inicial com o tema do trabalho
- Duas seções: **Casa** (lâmpada, portão, ar-condicionado, cortina) e **Indústria** (motor, esteira, cilindro pneumático, painel elétrico)
- Cada equipamento traz: o que é, onde está a física, a fórmula, um simulador interativo e a aplicação prática
- Uma aba **Roteiro** com o passo a passo sugerido para a apresentação ao vivo

## Como rodar localmente

Não precisa de servidor nem instalação — é um único arquivo HTML autocontido (HTML + CSS + JavaScript).

1. Abra a pasta no VS Code (`code .` no terminal, ou *File > Open Folder*)
2. Clique com o botão direito em `index.html` e escolha **"Open with Live Server"** (extensão recomendada abaixo), ou simplesmente dê duplo clique no arquivo para abrir direto no navegador

## Publicar no GitHub Pages (opcional)

1. Crie um repositório no GitHub e suba esta pasta (veja comandos abaixo)
2. Em **Settings > Pages**, selecione a branch `main` e a pasta `/root`
3. O site ficará disponível em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`

```bash
git init
git add .
git commit -m "Primeira versão do site: A Física na Automação"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git push -u origin main
```

## Extensão recomendada no VS Code

- **Live Server** (Ritwick Dey) — para abrir o site com recarregamento automático ao editar

## Estrutura da pasta

```
fisica-na-automacao/
├── index.html      # site completo (HTML + CSS + JS em um único arquivo)
├── README.md        # este arquivo
└── .gitignore
```
